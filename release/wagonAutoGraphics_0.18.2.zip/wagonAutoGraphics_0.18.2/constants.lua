
modVersion = "0.0.1" --version of control data, only updated when control.lua changes
modName = "wagonAutoGraphics" -- required prefix for all ui name components which can be clicked
fullModName = "wagonAutoGraphics" -- required for logging and prototypes


logging.debug_master = true
logging.testing = true -- enables player printing of every log, sets log level to info
--logging.testing = false
--logging.debug_level = 1  -- 1=info 2=warn 3=error
