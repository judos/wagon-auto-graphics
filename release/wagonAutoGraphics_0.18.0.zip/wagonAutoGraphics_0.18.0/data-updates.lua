
require "prototypes.basic-wagons"